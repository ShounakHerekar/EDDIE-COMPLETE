# tools.py
import requests
#import matplotlib.pyplot as plt
from fpdf import FPDF
import os

# === Base Config ===
BASE_URL = "https://data.sec.gov"
HEADERS = {
    "User-Agent": "Shounak/1.0 (Engineering Project; contact@example.com)",
    "Accept": "application/json"
}

# === 1️⃣ Convert Ticker → CIK ===
def get_cik(ticker: str):
    """Convert a company ticker (e.g., 'AAPL') into its 10-digit CIK."""
    url = "https://www.sec.gov/files/company_tickers.json"
    res = requests.get(url, headers=HEADERS)
    data = res.json()
    for _, info in data.items():
        if info["ticker"].lower() == ticker.lower():
            return str(info["cik_str"]).zfill(10)
    return None


# === 2️⃣ Get Basic Company Info ===
def get_company_info(cik: str):
    """Fetch basic info and latest submissions for the given company CIK."""
    url = f"{BASE_URL}/submissions/CIK{cik}.json"
    res = requests.get(url, headers=HEADERS)
    if res.status_code == 200:
        data = res.json()
        company_info = {
            "name": data.get("name"),
            "cik": cik,
            "sic_description": data.get("sicDescription"),
            "state": data.get("stateOfIncorporation"),
            "filings_count": len(data.get("filings", {}).get("recent", {}).get("accessionNumber", []))
        }
        return company_info
    return {"error": f"Failed to fetch info ({res.status_code})"}


# === 3️⃣ Get Filing Submissions ===
def get_company_submissions(cik: str):
    """Retrieve list of filings (10-K, 10-Q, 8-K, etc.) for the company."""
    url = f"{BASE_URL}/submissions/CIK{cik}.json"
    res = requests.get(url, headers=HEADERS)
    if res.status_code == 200:
        data = res.json()
        filings = data.get("filings", {}).get("recent", {})
        result = []
        for i in range(len(filings.get("accessionNumber", []))):
            result.append({
                "accession_number": filings["accessionNumber"][i],
                "filing_date": filings["filingDate"][i],
                "form": filings["form"][i],
                "report_date": filings["reportDate"][i],
            })
        return result
    return {"error": f"Failed to fetch submissions ({res.status_code})"}


# === 4️⃣ Get Financial Facts ===
# def get_company_facts(cik: str):
#     """Retrieve financial metrics like Revenue, Net Income, Assets, Liabilities, etc."""
#     url = f"{BASE_URL}/api/xbrl/companyfacts/CIK{cik}.json"
#     res = requests.get(url, headers=HEADERS)
#     if res.status_code == 200:
#         return res.json()
#     return {"error": f"Failed to fetch financial facts ({res.status_code})"}

BASE_URL = "https://data.sec.gov"
HEADERS = {
    "User-Agent": "Shounak/1.0 (Engineering Project; contact@example.com)",
    "Accept": "application/json"
}


def filter_company_facts(cik: str, year: int = None, quarter: int = None, metrics: list = None):
    """
    Retrieve and filter SEC company facts for a given CIK, year, quarter, and metrics.
    If metrics=None, fetches all key metrics (40+ GAAP tags).
    """

    url = f"{BASE_URL}/api/xbrl/companyfacts/CIK{cik}.json"
    res = requests.get(url, headers=HEADERS)
    if res.status_code != 200:
        return {"error": f"Failed to fetch financial facts ({res.status_code})"}

    data = res.json()
    facts = data.get("facts", {}).get("us-gaap", {})
    result = {}

    # 🧩 If user didn’t specify metrics, use the default 40+ key metrics
    if not metrics:
        metrics = [
            # Income Statement
            "Revenues", "CostOfRevenue", "GrossProfit", "OperatingExpenses",
            "OperatingIncomeLoss", "IncomeBeforeTax", "IncomeTaxExpenseBenefit",
            "NetIncomeLoss", "EarningsPerShareBasic", "EarningsPerShareDiluted",
            # Balance Sheet
            "Assets", "CurrentAssets", "Liabilities", "CurrentLiabilities",
            "StockholdersEquity", "CashAndCashEquivalentsAtCarryingValue",
            "InventoryNet", "AccountsReceivableNetCurrent",
            "PropertyPlantAndEquipmentNet", "LongTermDebtNoncurrent",
            "RetainedEarningsAccumulatedDeficit",
            # Cash Flow
            "NetCashProvidedByUsedInOperatingActivities",
            "NetCashProvidedByUsedInInvestingActivities",
            "NetCashProvidedByUsedInFinancingActivities",
            "PaymentsOfDividends", "PaymentsForRepurchaseOfCommonStock",
            "ProceedsFromIssuanceOfLongTermDebt", "RepaymentsOfLongTermDebt",
            "CashAndCashEquivalentsPeriodIncreaseDecrease",
            # Other
            "ResearchAndDevelopmentExpense", "SellingGeneralAndAdministrativeExpense",
            "ComprehensiveIncomeNetOfTax", "Goodwill", "IntangibleAssetsNetExcludingGoodwill",
            "CommonStockSharesOutstanding", "WeightedAverageNumberOfSharesOutstandingBasic",
            "WeightedAverageNumberOfSharesOutstandingDiluted"
        ]

    # Helper: check if a date belongs to a quarter
    def in_quarter(end_date, year, quarter):
        if not end_date or str(year) not in end_date:
            return False
        month = int(end_date.split("-")[1])
        return (
            (quarter == 1 and month in [1, 2, 3]) or
            (quarter == 2 and month in [4, 5, 6]) or
            (quarter == 3 and month in [7, 8, 9]) or
            (quarter == 4 and month in [10, 11, 12])
        )

    # 🧮 Filter and extract values
    for metric in metrics:
        if metric not in facts or "units" not in facts[metric]:
            continue

        usd_data = facts[metric]["units"].get("USD", [])
        if not usd_data:
            continue

        # Filter by year + quarter
        filtered = []
        for entry in usd_data:
            if year and "end" in entry:
                if quarter:
                    if in_quarter(entry["end"], year, quarter):
                        filtered.append(entry)
                elif str(year) in entry["end"]:
                    filtered.append(entry)
            elif not year:
                filtered.append(entry)

        if filtered:
            result[metric] = filtered

    # 🧾 Summarize last available values
    summary = {
        metric: result[metric][-1]["val"] if metric in result else None
        for metric in metrics
    }

    return {
        "cik": cik,
        "year": year,
        "quarter": quarter,
        "summary": summary,
        "details": result
    }


from datetime import datetime
def get_filings_10k_8k(cik: str, form_type: str, year: int = None, quarter: int = None, limit: int = 5):
    """
    Retrieve 10-K or 8-K filings for a given company, optionally filtered by year and quarter.
    form_type must be either '10-K' or '8-K'.
    """
    form_type = form_type.upper()
    if form_type not in ["10-K", "8-K"]:
        return {"error": "Only '10-K' and '8-K' forms are supported."}

    url = f"{BASE_URL}/submissions/CIK{cik}.json"
    res = requests.get(url, headers=HEADERS)
    if res.status_code != 200:
        return {"error": f"Failed to fetch filings ({res.status_code})"}

    data = res.json()
    filings = data.get("filings", {}).get("recent", {})

    results = []
    for i, form in enumerate(filings.get("form", [])):
        if form.upper() != form_type:
            continue

        filing_date = filings["filingDate"][i]
        accn = filings["accessionNumber"][i]
        doc = filings["primaryDocument"][i]

        try:
            fdate = datetime.strptime(filing_date, "%Y-%m-%d")
        except ValueError:
            continue

        # Apply year and quarter filters if provided
        if year and fdate.year != year:
            continue
        if quarter:
            q = (fdate.month - 1) // 3 + 1
            if q != quarter:
                continue

        filing_url = f"https://www.sec.gov/Archives/edgar/data/{int(cik):d}/{accn.replace('-', '')}/{doc}"

        results.append({
            "form": form,
            "filing_date": filing_date,
            "accession_number": accn,
            "filing_url": filing_url
        })

        if len(results) >= limit:
            break

    return {"count": len(results), "filings": results}



# === 5️⃣ Generate Graphs from Financial Data ===
# def generate_graphs(facts_data, output_dir="graphs"):
#     """Generate basic trend graphs (Revenue, Net Income, etc.) from facts data."""
#     os.makedirs(output_dir, exist_ok=True)
#     try:
#         revenue_data = facts_data["facts"]["us-gaap"]["Revenues"]["units"]["USD"]
#         years = [int(item["end"][:4]) for item in revenue_data]
#         values = [item["val"] for item in revenue_data]

#         plt.figure(figsize=(8, 4))
#         plt.plot(years, values, marker="o")
#         plt.title("Revenue Over Time")
#         plt.xlabel("Year")
#         plt.ylabel("Revenue (USD)")
#         plt.grid(True)

#         graph_path = os.path.join(output_dir, "revenue_trend.png")
#         plt.savefig(graph_path)
#         plt.close()
#         return graph_path
#     except Exception as e:
#         return {"error": f"Failed to generate graph: {str(e)}"}


# === 6️⃣ Generate PDF Financial Summary ===
# def generate_financial_summary_pdf(facts_data, output_path="financial_summary.pdf"):
#     """Generate a summarized financial report as a PDF."""
#     pdf = FPDF()
#     pdf.add_page()
#     pdf.set_font("Arial", "B", 16)
#     pdf.cell(0, 10, "Financial Summary Report", ln=True, align="C")

#     pdf.set_font("Arial", "", 12)
#     try:
#         facts = facts_data["facts"]["us-gaap"]
#         metrics = {
#             "Revenues": facts["Revenues"]["units"]["USD"][-1]["val"],
#             "Net Income": facts["NetIncomeLoss"]["units"]["USD"][-1]["val"],
#             "Total Assets": facts["Assets"]["units"]["USD"][-1]["val"],
#             "Total Liabilities": facts["Liabilities"]["units"]["USD"][-1]["val"],
#         }
#         for key, val in metrics.items():
#             pdf.cell(0, 10, f"{key}: {val:,}", ln=True)

#         pdf.output(output_path)
#         return output_path
#     except Exception as e:
#         return {"error": f"Failed to generate PDF: {str(e)}"}


# # === MAIN TEST (runs all functions sequentially) ===
# if __name__ == "__main__":
#     ticker = "AAPL"
#     print(f"\n🔍 Fetching data for {ticker}...\n")

#     # Step 1: Get CIK
#     cik = get_cik(ticker)
#     if not cik:
#         print("❌ Failed to find CIK. 1")
#         exit()
#     print(f"✅ CIK: {cik} 1")

#     # Step 2: Get Basic Info
#     info = get_company_info(cik)
#     if "error" in info:
#         print(f"❌ {info['error']} 2")
#         exit()
#     print(f"🏢 Company Info: {info} 2\n")

#     # Step 3: Get Filing Submissions
#     filings = get_company_submissions(cik)
#     if isinstance(filings, dict) and "error" in filings:
#         print(f"❌ {filings['error']} 3")
#     else:
#         print(f"🧾 Recent filings: {len(filings)} records fetched. 3\n")

#     # Step 4: Get Financial Facts
#     facts = get_company_facts(cik)
#     if "error" in facts:
#         print(f"❌ {facts['error']} 4")
#         exit()
#     print("📊 Financial facts retrieved successfully.\n 4")

#     # Step 5: Generate Graph
#     graph_path = generate_graphs(facts)
#     if isinstance(graph_path, dict) and "error" in graph_path:
#         print(f"❌ {graph_path['error']} 5")
#     else:
#         print(f"📈 Graph saved at: {graph_path} 5")

#     # Step 6: Generate PDF Summary
#     pdf_path = generate_financial_summary_pdf(facts)
#     if isinstance(pdf_path, dict) and "error" in pdf_path:
#         print(f"❌ {pdf_path['error']} 6")
#     else:
#         print(f"📄 PDF summary generated: {pdf_path} 6")

#     print("\n✅ All operations completed successfully!\n")
