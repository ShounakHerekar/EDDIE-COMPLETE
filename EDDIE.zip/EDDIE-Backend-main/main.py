from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import os
from tools import (
    get_cik,
    get_company_info,
    get_company_submissions,
    # generate_graphs,
    # generate_financial_summary_pdf,
    filter_company_facts,
    get_filings_10k_8k
)

# === Initialize FastAPI ===
app = FastAPI(title="EDGAR Dispatch API (Full Version)")

# Ensure reports folder exists
os.makedirs("reports", exist_ok=True)


# === Input Schema ===
class DispatchRequest(BaseModel):
    ticker: str
    actions: List[str]
    report_type: Optional[str] = "10-K"
    form_type: Optional[str] = None  # For 10-K / 8-K retrieval
    year: Optional[int] = None
    quarter: Optional[int] = None
    metrics: Optional[List[str]] = None


# === Dispatch Route ===
@app.post("/dispatch")
def dispatch(req: DispatchRequest):
    """
    Unified EDGAR dispatch handler — supports:
    - get_cik
    - get_company_info
    - get_company_submissions
    - get_company_facts (filtered)
    - generate_graphs
    - generate_pdf
    - get_filings_10k_8k (for 10-K & 8-K filings)
    """
    try:
        ticker = req.ticker.upper()
        report_type = req.report_type.upper() if req.report_type else "10-K"
        results: Dict[str, Any] = {}

        print(f"🚀 Dispatch triggered for {ticker} | Actions: {req.actions}")

        cik = None
        facts = None

        for action in req.actions:

            # === Get CIK ===
            if action == "get_cik":
                cik = get_cik(ticker)
                if not cik:
                    raise HTTPException(status_code=404, detail=f"CIK not found for {ticker}")
                results["cik"] = cik

            # === Get Company Info ===
            elif action == "get_company_info":
                if not cik:
                    cik = get_cik(ticker)
                company_info = get_company_info(cik)
                results["company_info"] = company_info

            # === Get Submissions / Filings List ===
            elif action == "get_company_submissions":
                if not cik:
                    cik = get_cik(ticker)
                filings = get_company_submissions(cik)
                results["filings"] = filings

            # === Get Filtered Company Facts ===
            elif action == "get_company_facts":
                if not cik:
                    cik = get_cik(ticker)
                facts = filter_company_facts(
                    cik,
                    year=req.year,
                    quarter=req.quarter,
                    metrics=req.metrics
                )
                results["facts"] = facts

            # === Generate Graphs (from facts) ===
            # elif action == "generate_graphs":
            #     if not facts:
            #         if not cik:
            #             cik = get_cik(ticker)
            #         facts = filter_company_facts(cik)
            #     graph_path = generate_graphs(facts, output_dir="reports")
            #     results["graph_path"] = graph_path

            # === Generate Financial Summary PDF ===
            # elif action == "generate_pdf":
            #     if not facts:
            #         if not cik:
            #             cik = get_cik(ticker)
            #         facts = filter_company_facts(cik)
            #     pdf_filename = f"{ticker}_{report_type}.pdf"
            #     pdf_path = os.path.join("reports", pdf_filename)
            #     generate_financial_summary_pdf(facts, output_path=pdf_path)
            #     results["pdf_path"] = pdf_path

            # === Get 10-K / 8-K Filings ===
            elif action == "get_filings_10k_8k":
                if not cik:
                    cik = get_cik(ticker)
                if not req.form_type or req.form_type.upper() not in ["10-K", "8-K"]:
                    raise HTTPException(
                        status_code=400,
                        detail="Invalid or missing form type. Must be '10-K' or '8-K'."
                    )
                filings_summary = get_filings_10k_8k(
                    cik=cik,
                    form_type=req.form_type.upper(),
                    year=req.year,
                    quarter=req.quarter
                )
                if "error" in filings_summary:
                    raise HTTPException(status_code=500, detail=filings_summary["error"])
                results["filings_summary"] = filings_summary

            # === Unknown Action ===
            else:
                raise HTTPException(status_code=400, detail=f"Unknown action: {action}")

        return {
            "status": "success",
            "results": results
        }

    except HTTPException as e:
        raise e
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
